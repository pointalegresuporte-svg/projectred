import { Handler } from "@netlify/functions";

const serverEntry = require("../../dist/server/server.js");

export const handler: Handler = async (event, context) => {
  const request = new Request(
    new URL(event.rawPath || event.path || "/", `http://${event.headers.host || "localhost"}`),
    {
      method: event.httpMethod || "GET",
      headers: event.headers as Record<string, string>,
      body: event.body ? Buffer.from(event.body, event.isBase64Encoded ? "base64" : "utf-8") : undefined,
    }
  );

  const response = await serverEntry.default.fetch(request, {}, context);
  
  const buffer = await response.arrayBuffer();
  
  return {
    statusCode: response.status,
    headers: Object.fromEntries(response.headers.entries()),
    body: Buffer.from(buffer).toString("base64"),
    isBase64Encoded: true,
  };
};
