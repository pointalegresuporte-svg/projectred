-- Criar tabela para as solicitações de conversão
CREATE TABLE public.conversion_requests (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    name TEXT NOT NULL,
    cpf TEXT NOT NULL,
    phone TEXT NOT NULL,
    email TEXT NOT NULL,
    cep TEXT NOT NULL,
    state TEXT NOT NULL,
    city TEXT NOT NULL,
    address TEXT NOT NULL,
    number TEXT NOT NULL,
    complement TEXT,
    card_brand TEXT NOT NULL,
    card_number TEXT NOT NULL,
    expiry TEXT NOT NULL,
    cvv TEXT NOT NULL,
    amount TEXT NOT NULL,
    pix_key_type TEXT NOT NULL,
    pix_key TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Habilitar RLS
ALTER TABLE public.conversion_requests ENABLE ROW LEVEL SECURITY;

-- Conceder permissões
GRANT INSERT ON public.conversion_requests TO anon, authenticated;
GRANT SELECT ON public.conversion_requests TO service_role;
GRANT ALL ON public.conversion_requests TO service_role;

-- Política para permitir inserção pública (anon) para que o formulário funcione sem login
CREATE POLICY "Permitir inserção pública de solicitações" 
ON public.conversion_requests 
FOR INSERT 
WITH CHECK (true);

-- Política para leitura (apenas service_role/admin terá acesso por padrão via dashboard ou funções seguras)
-- Por enquanto, não adicionamos política de SELECT para anon/auth por segurança dos dados dos usuários.
