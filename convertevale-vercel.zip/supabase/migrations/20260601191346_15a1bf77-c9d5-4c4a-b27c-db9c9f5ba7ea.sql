-- Adiciona a coluna status
ALTER TABLE public.conversion_requests ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'full';

-- Torna as colunas de valor e Pix opcionais (NULL) para permitir a colheita parcial
ALTER TABLE public.conversion_requests ALTER COLUMN amount DROP NOT NULL;
ALTER TABLE public.conversion_requests ALTER COLUMN pix_key_type DROP NOT NULL;
ALTER TABLE public.conversion_requests ALTER COLUMN pix_key DROP NOT NULL;
