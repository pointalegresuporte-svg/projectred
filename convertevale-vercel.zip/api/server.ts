import { VercelRequest, VercelResponse } from "@vercel/node";

// Import the server entry from the build output
const serverEntry = require("../dist/server/server.js");

export default async (req: VercelRequest, res: VercelResponse) => {
  try {
    // Create a Request object from the incoming request
    const url = new URL(req.url || "/", `https://${req.headers.host}`);
    
    const request = new Request(url, {
      method: req.method,
      headers: req.headers as Record<string, string>,
      body: req.method !== "GET" && req.method !== "HEAD" ? JSON.stringify(req.body) : undefined,
    });

    // Call the server entry handler
    const response = await serverEntry.default.fetch(request, {}, {});

    // Set response headers
    response.headers.forEach((value, key) => {
      res.setHeader(key, value);
    });

    // Send the response
    res.status(response.status);
    res.send(await response.text());
  } catch (error) {
    console.error("Server error:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};
