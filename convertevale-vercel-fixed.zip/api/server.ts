import type { VercelRequest, VercelResponse } from "@vercel/node";

let serverEntry: any;

async function getServerEntry() {
  if (!serverEntry) {
    try {
      serverEntry = await import("@tanstack/react-start/server-entry").then(
        (m) => (m.default ?? m)
      );
    } catch (error) {
      console.error("Failed to load server entry:", error);
      throw error;
    }
  }
  return serverEntry;
}

export default async (req: VercelRequest, res: VercelResponse) => {
  try {
    const handler = await getServerEntry();

    const protocol = req.headers["x-forwarded-proto"] || "https";
    const host = req.headers["x-forwarded-host"] || req.headers.host || "localhost";
    const url = new URL(req.url || "/", `${protocol}://${host}`);

    const request = new Request(url, {
      method: req.method || "GET",
      headers: req.headers as Record<string, string>,
      body:
        req.method && req.method !== "GET" && req.method !== "HEAD"
          ? JSON.stringify(req.body || {})
          : undefined,
    });

    const response = await handler.fetch(request, {}, {});

    response.headers.forEach((value, key) => {
      res.setHeader(key, value);
    });

    res.status(response.status);
    const text = await response.text();
    res.send(text);
  } catch (error) {
    console.error("Server error:", error);
    res.status(500).json({
      error: "Internal Server Error",
      message: error instanceof Error ? error.message : "Unknown error",
    });
  }
};
